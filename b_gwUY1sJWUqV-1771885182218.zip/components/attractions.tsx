"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import { Music } from "lucide-react"

const djs = [
  {
    name: "DJ KAYO",
    genre: "Funk & Bass",
    image: "/images/dj-kayo.jpg",
    time: "23h - 01h",
  },
  {
    name: "LUNA BEATS",
    genre: "House & Eletronico",
    image: "/images/dj-luna.jpg",
    time: "01h - 03h30",
  },
  {
    name: "VXN",
    genre: "Pop & Tech House",
    image: "/images/dj-vxn.jpg",
    time: "03h30 - 06h",
  },
]

export function Attractions() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true)
      },
      { threshold: 0.15 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section id="atracoes" ref={sectionRef} className="relative py-24 lg:py-32">
      {/* Background accent */}
      <div className="absolute left-0 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-accent/5 blur-[120px]" />

      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        {/* Section header */}
        <div className={`mb-16 text-center transition-all duration-700 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}>
          <span className="mb-4 inline-block text-sm font-semibold uppercase tracking-widest text-primary">
            Line-up
          </span>
          <h2 className="mb-4 text-4xl font-bold text-foreground md:text-5xl text-balance">
            Atracoes confirmadas
          </h2>
          <p className="mx-auto max-w-md text-muted-foreground">
            Os melhores DJs para uma noite inesquecivel
          </p>
        </div>

        {/* DJ cards */}
        <div className="grid gap-8 md:grid-cols-3">
          {djs.map((dj, index) => (
            <div
              key={dj.name}
              className={`group relative overflow-hidden rounded-2xl border border-border bg-card transition-all duration-700 hover:border-primary/40 ${
                isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"
              }`}
              style={{ transitionDelay: `${200 + index * 150}ms` }}
            >
              {/* DJ Image */}
              <div className="relative aspect-[3/4] overflow-hidden">
                <Image
                  src={dj.image}
                  alt={dj.name}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                  sizes="(max-width: 768px) 100vw, 33vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#050208] via-[#050208]/30 to-transparent" />

                {/* Time badge */}
                <div className="absolute right-4 top-4 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 backdrop-blur-sm">
                  <span className="text-xs font-semibold text-primary">{dj.time}</span>
                </div>

                {/* DJ Info overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <Music className="h-4 w-4 text-primary" />
                    <span className="text-xs font-medium uppercase tracking-wider text-primary">{dj.genre}</span>
                  </div>
                  <h3 className="text-3xl font-black uppercase tracking-tight text-foreground">{dj.name}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import { MapPin, Lock, Car } from "lucide-react"

export function Venue() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true)
      },
      { threshold: 0.15 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section id="local" ref={sectionRef} className="relative py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          {/* Image */}
          <div
            className={`relative overflow-hidden rounded-2xl transition-all duration-700 ${
              isVisible ? "translate-x-0 opacity-100" : "-translate-x-10 opacity-0"
            }`}
          >
            <div className="relative aspect-[4/3]">
              <Image
                src="/images/venue.jpg"
                alt="Casa exclusiva do evento"
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 50vw"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#050208]/60 to-transparent" />
            </div>
            {/* Neon border effect */}
            <div className="absolute inset-0 rounded-2xl border border-primary/20" />
          </div>

          {/* Content */}
          <div
            className={`transition-all duration-700 ${
              isVisible ? "translate-x-0 opacity-100" : "translate-x-10 opacity-0"
            }`}
            style={{ transitionDelay: "200ms" }}
          >
            <span className="mb-4 inline-block text-sm font-semibold uppercase tracking-widest text-primary">
              Local
            </span>
            <h2 className="mb-6 text-4xl font-bold text-foreground md:text-5xl text-balance">
              Casa exclusiva em BH
            </h2>
            <p className="mb-8 text-lg leading-relaxed text-muted-foreground">
              Uma localizacao privilegiada na regiao nobre de Belo Horizonte. Espaco privado com infraestrutura completa, piscina, area externa e ambiente climatizado para uma experiencia inesquecivel.
            </p>

            {/* Info items */}
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4">
                <div className="rounded-lg bg-primary/10 p-2">
                  <MapPin className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">Regiao da Pampulha</p>
                  <p className="text-sm text-muted-foreground">Belo Horizonte - MG</p>
                </div>
              </div>
              <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4">
                <div className="rounded-lg bg-accent/10 p-2">
                  <Lock className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">Endereco revelado via WhatsApp</p>
                  <p className="text-sm text-muted-foreground">Apenas para confirmados na lista</p>
                </div>
              </div>
              <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4">
                <div className="rounded-lg bg-neon-cyan/10 p-2">
                  <Car className="h-5 w-5 text-neon-cyan" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">Estacionamento privativo</p>
                  <p className="text-sm text-muted-foreground">Vagas limitadas no local</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

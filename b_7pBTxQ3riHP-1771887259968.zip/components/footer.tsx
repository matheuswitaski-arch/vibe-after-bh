import { Instagram, Mail, MapPin } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-border bg-card py-12">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="flex flex-col items-center gap-8 md:flex-row md:justify-between">
          {/* Brand */}
          <div className="text-center md:text-left">
            <p className="text-xl font-bold tracking-wider text-foreground">
              VIBE<span className="text-primary"> AFTER</span> BH
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              O after mais insano de Belo Horizonte
            </p>
          </div>

          {/* Links */}
          <div className="flex items-center gap-6">
            <a
              href="https://instagram.com/vibeafterbh"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
              aria-label="Instagram do VIBE AFTER BH"
            >
              <Instagram className="h-5 w-5" />
              <span className="hidden sm:inline">@vibeafterbh</span>
            </a>
            <a
              href="mailto:contato@vibeafterbh.com"
              className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
              aria-label="Email de contato"
            >
              <Mail className="h-5 w-5" />
              <span className="hidden sm:inline">contato@vibeafterbh.com</span>
            </a>
          </div>

          {/* Location */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4" />
            <span>Belo Horizonte - MG</span>
          </div>
        </div>

        {/* Bottom line */}
        <div className="mt-8 border-t border-border pt-8 text-center">
          <p className="text-xs text-muted-foreground">
            {'VIBE AFTER BH - Todos os direitos reservados.'}
          </p>
        </div>
      </div>
    </footer>
  )
}

"use client"

import { useEffect, useRef, useState } from "react"
import { Sparkles, Users, Music, Shield } from "lucide-react"

const features = [
  {
    icon: Sparkles,
    title: "Experiencia Unica",
    description: "Producao de altissimo nivel com efeitos visuais e sonoros que transformam a noite.",
  },
  {
    icon: Users,
    title: "Publico Selecionado",
    description: "Ambiente exclusivo com lista curada para garantir a melhor vibe da noite.",
  },
  {
    icon: Music,
    title: "Open Vibes",
    description: "Funk, eletronico, pop e house. A melhor selecao musical sem parar.",
  },
  {
    icon: Shield,
    title: "Seguranca Total",
    description: "Equipe profissional para voce curtir com tranquilidade e liberdade.",
  },
]

export function About() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true)
      },
      { threshold: 0.2 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section id="sobre" ref={sectionRef} className="relative py-24 lg:py-32">
      {/* Background accent */}
      <div className="absolute right-0 top-0 h-96 w-96 rounded-full bg-primary/5 blur-[120px]" />

      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        {/* Section header */}
        <div className={`mb-16 max-w-2xl transition-all duration-700 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}>
          <span className="mb-4 inline-block text-sm font-semibold uppercase tracking-widest text-primary">
            Sobre o evento
          </span>
          <h2 className="mb-6 text-4xl font-bold text-foreground md:text-5xl text-balance">
            O after que BH estava esperando
          </h2>
          <p className="text-lg leading-relaxed text-muted-foreground">
            O VIBE AFTER BH e o after exclusivo pos-evento que reune o melhor publico da noite de Belo Horizonte. Uma experiencia unica em uma localizacao privilegiada, com producao impecavel e a energia que so a noite de BH consegue proporcionar.
          </p>
        </div>

        {/* Feature cards */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className={`group relative overflow-hidden rounded-xl border border-border bg-card p-6 transition-all duration-700 hover:border-primary/40 hover:neon-border ${
                isVisible
                  ? "translate-y-0 opacity-100"
                  : "translate-y-10 opacity-0"
              }`}
              style={{ transitionDelay: `${200 + index * 100}ms` }}
            >
              <div className="mb-4 inline-flex rounded-lg bg-primary/10 p-3">
                <feature.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-lg font-bold text-foreground">{feature.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{feature.description}</p>
              {/* Hover glow */}
              <div className="absolute -bottom-1 -right-1 h-24 w-24 rounded-full bg-primary/0 transition-all duration-500 group-hover:bg-primary/10 group-hover:blur-2xl" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

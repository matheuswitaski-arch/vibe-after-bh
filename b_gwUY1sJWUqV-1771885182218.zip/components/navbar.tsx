"use client"

import { useState, useEffect } from "react"
import { Menu, X } from "lucide-react"
import { WhatsAppCTA } from "./whatsapp-button"
import { cn } from "@/lib/utils"

const navLinks = [
  { label: "Sobre", href: "#sobre" },
  { label: "Atracoes", href: "#atracoes" },
  { label: "Local", href: "#local" },
  { label: "Galeria", href: "#galeria" },
  { label: "Patrocinio", href: "#patrocinio" },
]

export function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-40 transition-all duration-500",
        scrolled ? "glass py-3" : "bg-transparent py-5"
      )}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 lg:px-8">
        <a href="#" className="text-xl font-bold tracking-wider text-foreground">
          VIBE<span className="text-primary"> AFTER</span>
        </a>

        {/* Desktop Nav */}
        <div className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium uppercase tracking-widest text-muted-foreground transition-colors hover:text-primary"
            >
              {link.label}
            </a>
          ))}
          <WhatsAppCTA variant="default" className="text-sm">
            Quero ir
          </WhatsAppCTA>
        </div>

        {/* Mobile toggle */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="text-foreground md:hidden"
          aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
        >
          {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="glass absolute inset-x-0 top-full border-t border-border md:hidden">
          <div className="flex flex-col gap-4 px-4 py-6">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="text-sm font-medium uppercase tracking-widest text-muted-foreground transition-colors hover:text-primary"
              >
                {link.label}
              </a>
            ))}
            <WhatsAppCTA variant="default" className="mt-2 w-full justify-center text-sm">
              Quero ir
            </WhatsAppCTA>
          </div>
        </div>
      )}
    </header>
  )
}

"use client"

import { useEffect, useRef, useState } from "react"
import { WhatsAppCTA } from "./whatsapp-button"
import { Handshake } from "lucide-react"

export function Sponsors() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true)
      },
      { threshold: 0.2 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section id="patrocinio" ref={sectionRef} className="relative py-24 lg:py-32">
      <div className="absolute left-1/2 top-0 h-96 w-96 -translate-x-1/2 rounded-full bg-primary/5 blur-[120px]" />

      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div
          className={`relative overflow-hidden rounded-2xl border border-border bg-card p-8 md:p-16 transition-all duration-700 ${
            isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"
          }`}
        >
          {/* Inner glow */}
          <div className="absolute -left-20 -top-20 h-64 w-64 rounded-full bg-primary/10 blur-[80px]" />
          <div className="absolute -bottom-20 -right-20 h-64 w-64 rounded-full bg-accent/10 blur-[80px]" />

          <div className="relative text-center">
            <span className="mb-4 inline-block text-sm font-semibold uppercase tracking-widest text-primary">
              Patrocinio
            </span>
            <h2 className="mb-6 text-4xl font-bold text-foreground md:text-5xl text-balance">
              Patrocinio confirmado
            </h2>

            {/* Brahma logo area */}
            <div className="mb-10 flex items-center justify-center">
              <div className="flex items-center justify-center rounded-2xl border border-border bg-secondary/50 px-12 py-8">
                <span className="text-4xl font-black uppercase tracking-wider text-foreground md:text-5xl">
                  BRAHMA
                </span>
              </div>
            </div>

            {/* Divider */}
            <div className="mx-auto mb-10 h-px w-48 bg-gradient-to-r from-transparent via-primary/40 to-transparent" />

            {/* Sponsor CTA */}
            <div className="flex flex-col items-center gap-4">
              <div className="flex items-center gap-2">
                <Handshake className="h-5 w-5 text-muted-foreground" />
                <p className="text-lg text-muted-foreground">
                  Marcas interessadas em parceria, entre em contato
                </p>
              </div>
              <WhatsAppCTA variant="outline" isSponsor>
                Quero ser patrocinador
              </WhatsAppCTA>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { cn } from "@/lib/utils"
import {
  Menu, X, CalendarDays, Clock, MapPin, Sparkles, Users, Music,
  Shield, Lock, Car, Instagram, Mail, Handshake,
} from "lucide-react"

// ── Constants ────────────────────────────────────────────────────────────────

const WHATSAPP_LINK = "https://wa.me/5531999999999?text=Quero%20participar%20do%20VIBE%20AFTER%20BH!"
const WHATSAPP_SPONSOR_LINK = "https://wa.me/5531999999999?text=Tenho%20interesse%20em%20patrocinar%20o%20VIBE%20AFTER%20BH"

const NAV_LINKS = [
  { label: "Sobre", href: "#sobre" },
  { label: "Atracoes", href: "#atracoes" },
  { label: "Local", href: "#local" },
  { label: "Galeria", href: "#galeria" },
  { label: "Patrocinio", href: "#patrocinio" },
]

const FEATURES = [
  { icon: Sparkles, title: "Experiencia Unica", description: "Producao de altissimo nivel com efeitos visuais e sonoros que transformam a noite." },
  { icon: Users, title: "Publico Selecionado", description: "Ambiente exclusivo com lista curada para garantir a melhor vibe da noite." },
  { icon: Music, title: "Open Vibes", description: "Funk, eletronico, pop e house. A melhor selecao musical sem parar." },
  { icon: Shield, title: "Seguranca Total", description: "Equipe profissional para voce curtir com tranquilidade e liberdade." },
]

const DJS = [
  { name: "DJ KAYO", genre: "Funk & Bass", image: "/images/dj-kayo.jpg", time: "23h - 01h" },
  { name: "LUNA BEATS", genre: "House & Eletronico", image: "/images/dj-luna.jpg", time: "01h - 03h30" },
  { name: "VXN", genre: "Pop & Tech House", image: "/images/dj-vxn.jpg", time: "03h30 - 06h" },
]

const GALLERY_IMAGES = [
  { src: "/images/gallery-1.jpg", alt: "Publico na pista de danca" },
  { src: "/images/gallery-2.jpg", alt: "DJ na mesa de som" },
  { src: "/images/gallery-3.jpg", alt: "Bar com drinks neon" },
  { src: "/images/gallery-4.jpg", alt: "Area VIP da festa" },
]

// ── Shared Helpers ───────────────────────────────────────────────────────────

function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}

function WhatsAppCTA({
  children,
  variant = "default",
  className,
  isSponsor = false,
}: {
  children: React.ReactNode
  variant?: "default" | "outline" | "large"
  className?: string
  isSponsor?: boolean
}) {
  const link = isSponsor ? WHATSAPP_SPONSOR_LINK : WHATSAPP_LINK
  return (
    <a
      href={link}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        "inline-flex items-center gap-2 font-semibold transition-all duration-300 cursor-pointer",
        variant === "default" &&
          "rounded-lg bg-[#25D366] px-6 py-3 text-[#050208] hover:bg-[#20bd5a] hover:shadow-[0_0_20px_rgba(37,211,102,0.4)]",
        variant === "outline" &&
          "rounded-lg border-2 border-[#25D366] px-6 py-3 text-[#25D366] hover:bg-[#25D366]/10",
        variant === "large" &&
          "rounded-xl bg-[#25D366] px-8 py-4 text-lg text-[#050208] hover:bg-[#20bd5a] hover:shadow-[0_0_30px_rgba(37,211,102,0.5)] hover:scale-105",
        className
      )}
    >
      <WhatsAppIcon className="h-5 w-5" />
      {children}
    </a>
  )
}

function useInView(threshold = 0.2) {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setIsVisible(true) },
      { threshold }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [threshold])
  return { ref, isVisible }
}

// ── Sections ─────────────────────────────────────────────────────────────────

function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header className={cn(
      "fixed top-0 left-0 right-0 z-40 transition-all duration-500",
      scrolled ? "glass py-3" : "bg-transparent py-5"
    )}>
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 lg:px-8">
        <a href="#" className="text-xl font-bold tracking-wider text-foreground">
          VIBE<span className="text-primary"> AFTER</span>
        </a>
        <div className="hidden items-center gap-8 md:flex">
          {NAV_LINKS.map((link) => (
            <a key={link.href} href={link.href} className="text-sm font-medium uppercase tracking-widest text-muted-foreground transition-colors hover:text-primary">
              {link.label}
            </a>
          ))}
          <WhatsAppCTA variant="default" className="text-sm">Quero ir</WhatsAppCTA>
        </div>
        <button onClick={() => setMenuOpen(!menuOpen)} className="text-foreground md:hidden" aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}>
          {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>
      {menuOpen && (
        <div className="glass absolute inset-x-0 top-full border-t border-border md:hidden">
          <div className="flex flex-col gap-4 px-4 py-6">
            {NAV_LINKS.map((link) => (
              <a key={link.href} href={link.href} onClick={() => setMenuOpen(false)} className="text-sm font-medium uppercase tracking-widest text-muted-foreground transition-colors hover:text-primary">
                {link.label}
              </a>
            ))}
            <WhatsAppCTA variant="default" className="mt-2 w-full justify-center text-sm">Quero ir</WhatsAppCTA>
          </div>
        </div>
      )}
    </header>
  )
}

function Hero() {
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      if (heroRef.current) heroRef.current.style.transform = `translateY(${window.scrollY * 0.3}px)`
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <section className="relative flex min-h-screen items-center justify-center overflow-hidden">
      <div ref={heroRef} className="absolute inset-0 -z-10">
        <Image src="/images/hero-bg.jpg" alt="VIBE AFTER BH - festa" fill priority className="object-cover" sizes="100vw" />
        <div className="absolute inset-0 bg-[#050208]/70" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#050208]/30 via-transparent to-[#050208]" />
      </div>
      <div className="absolute left-1/4 top-1/4 h-96 w-96 rounded-full bg-primary/20 blur-[120px] animate-glow-pulse" />
      <div className="absolute right-1/4 bottom-1/4 h-72 w-72 rounded-full bg-accent/20 blur-[100px] animate-glow-pulse" style={{ animationDelay: "1.5s" }} />
      <div className="relative z-10 mx-auto max-w-5xl px-4 text-center">
        <div className="mb-8 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2">
          <CalendarDays className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium text-primary">15 de Marco de 2026</span>
        </div>
        <h1 className="mb-2 text-6xl font-black uppercase tracking-tight text-foreground md:text-8xl lg:text-9xl">
          <span className="block">VIBE</span>
          <span className="neon-text block text-primary">AFTER</span>
          <span className="block text-3xl font-bold tracking-[0.3em] text-muted-foreground md:text-4xl">BELO HORIZONTE</span>
        </h1>
        <p className="mx-auto mb-8 max-w-xl text-lg font-medium text-foreground/80 md:text-xl text-balance">O after mais insano de BH</p>
        <div className="mb-10 flex flex-wrap items-center justify-center gap-4">
          <div className="flex items-center gap-2 rounded-full border border-border bg-secondary/50 px-4 py-2">
            <Clock className="h-4 w-4 text-primary" />
            <span className="text-sm text-muted-foreground">23h - 06h</span>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-border bg-secondary/50 px-4 py-2">
            <MapPin className="h-4 w-4 text-accent" />
            <span className="text-sm text-muted-foreground">Casa exclusiva - BH</span>
          </div>
        </div>
        <WhatsAppCTA variant="large">Quero participar</WhatsAppCTA>
        <div className="mt-16 flex flex-col items-center gap-2">
          <span className="text-xs uppercase tracking-widest text-muted-foreground">Role para baixo</span>
          <div className="h-10 w-[1px] bg-gradient-to-b from-primary/60 to-transparent animate-glow-pulse" />
        </div>
      </div>
    </section>
  )
}

function About() {
  const { ref: sectionRef, isVisible } = useInView(0.2)
  return (
    <section id="sobre" ref={sectionRef} className="relative py-24 lg:py-32">
      <div className="absolute right-0 top-0 h-96 w-96 rounded-full bg-primary/5 blur-[120px]" />
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className={`mb-16 max-w-2xl transition-all duration-700 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}>
          <span className="mb-4 inline-block text-sm font-semibold uppercase tracking-widest text-primary">Sobre o evento</span>
          <h2 className="mb-6 text-4xl font-bold text-foreground md:text-5xl text-balance">O after que BH estava esperando</h2>
          <p className="text-lg leading-relaxed text-muted-foreground">
            O VIBE AFTER BH e o after exclusivo pos-evento que reune o melhor publico da noite de Belo Horizonte. Uma experiencia unica em uma localizacao privilegiada, com producao impecavel e a energia que so a noite de BH consegue proporcionar.
          </p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((feature, index) => (
            <div
              key={feature.title}
              className={`group relative overflow-hidden rounded-xl border border-border bg-card p-6 transition-all duration-700 hover:border-primary/40 hover:neon-border ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}
              style={{ transitionDelay: `${200 + index * 100}ms` }}
            >
              <div className="mb-4 inline-flex rounded-lg bg-primary/10 p-3">
                <feature.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-lg font-bold text-foreground">{feature.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{feature.description}</p>
              <div className="absolute -bottom-1 -right-1 h-24 w-24 rounded-full bg-primary/0 transition-all duration-500 group-hover:bg-primary/10 group-hover:blur-2xl" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function Attractions() {
  const { ref: sectionRef, isVisible } = useInView(0.15)
  return (
    <section id="atracoes" ref={sectionRef} className="relative py-24 lg:py-32">
      <div className="absolute left-0 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-accent/5 blur-[120px]" />
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className={`mb-16 text-center transition-all duration-700 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}>
          <span className="mb-4 inline-block text-sm font-semibold uppercase tracking-widest text-primary">Line-up</span>
          <h2 className="mb-4 text-4xl font-bold text-foreground md:text-5xl text-balance">Atracoes confirmadas</h2>
          <p className="mx-auto max-w-md text-muted-foreground">Os melhores DJs para uma noite inesquecivel</p>
        </div>
        <div className="grid gap-8 md:grid-cols-3">
          {DJS.map((dj, index) => (
            <div
              key={dj.name}
              className={`group relative overflow-hidden rounded-2xl border border-border bg-card transition-all duration-700 hover:border-primary/40 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}
              style={{ transitionDelay: `${200 + index * 150}ms` }}
            >
              <div className="relative aspect-[3/4] overflow-hidden">
                <Image src={dj.image} alt={dj.name} fill className="object-cover transition-transform duration-700 group-hover:scale-110" sizes="(max-width: 768px) 100vw, 33vw" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#050208] via-[#050208]/30 to-transparent" />
                <div className="absolute right-4 top-4 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 backdrop-blur-sm">
                  <span className="text-xs font-semibold text-primary">{dj.time}</span>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <div className="mb-2 flex items-center gap-2">
                    <Music className="h-4 w-4 text-primary" />
                    <span className="text-xs font-medium uppercase tracking-wider text-primary">{dj.genre}</span>
                  </div>
                  <h3 className="text-3xl font-black uppercase tracking-tight text-foreground">{dj.name}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function Venue() {
  const { ref: sectionRef, isVisible } = useInView(0.15)
  return (
    <section id="local" ref={sectionRef} className="relative py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className={`relative overflow-hidden rounded-2xl transition-all duration-700 ${isVisible ? "translate-x-0 opacity-100" : "-translate-x-10 opacity-0"}`}>
            <div className="relative aspect-[4/3]">
              <Image src="/images/venue.jpg" alt="Casa exclusiva do evento" fill className="object-cover" sizes="(max-width: 1024px) 100vw, 50vw" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#050208]/60 to-transparent" />
            </div>
            <div className="absolute inset-0 rounded-2xl border border-primary/20" />
          </div>
          <div className={`transition-all duration-700 ${isVisible ? "translate-x-0 opacity-100" : "translate-x-10 opacity-0"}`} style={{ transitionDelay: "200ms" }}>
            <span className="mb-4 inline-block text-sm font-semibold uppercase tracking-widest text-primary">Local</span>
            <h2 className="mb-6 text-4xl font-bold text-foreground md:text-5xl text-balance">Casa exclusiva em BH</h2>
            <p className="mb-8 text-lg leading-relaxed text-muted-foreground">
              Uma localizacao privilegiada na regiao nobre de Belo Horizonte. Espaco privado com infraestrutura completa, piscina, area externa e ambiente climatizado para uma experiencia inesquecivel.
            </p>
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4">
                <div className="rounded-lg bg-primary/10 p-2"><MapPin className="h-5 w-5 text-primary" /></div>
                <div>
                  <p className="font-semibold text-foreground">Regiao da Pampulha</p>
                  <p className="text-sm text-muted-foreground">Belo Horizonte - MG</p>
                </div>
              </div>
              <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4">
                <div className="rounded-lg bg-accent/10 p-2"><Lock className="h-5 w-5 text-accent" /></div>
                <div>
                  <p className="font-semibold text-foreground">Endereco revelado via WhatsApp</p>
                  <p className="text-sm text-muted-foreground">Apenas para confirmados na lista</p>
                </div>
              </div>
              <div className="flex items-center gap-4 rounded-xl border border-border bg-card p-4">
                <div className="rounded-lg bg-neon-cyan/10 p-2"><Car className="h-5 w-5 text-neon-cyan" /></div>
                <div>
                  <p className="font-semibold text-foreground">Estacionamento privativo</p>
                  <p className="text-sm text-muted-foreground">Vagas limitadas no local</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function Gallery() {
  const { ref: sectionRef, isVisible } = useInView(0.1)
  return (
    <section id="galeria" ref={sectionRef} className="relative py-24 lg:py-32">
      <div className="absolute right-0 bottom-0 h-96 w-96 rounded-full bg-neon-pink/5 blur-[120px]" />
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className={`mb-16 text-center transition-all duration-700 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}>
          <span className="mb-4 inline-block text-sm font-semibold uppercase tracking-widest text-primary">Galeria</span>
          <h2 className="mb-4 text-4xl font-bold text-foreground md:text-5xl text-balance">Sinta a energia</h2>
          <p className="mx-auto max-w-md text-muted-foreground">Momentos das nossas edicoes anteriores</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {GALLERY_IMAGES.map((img, index) => (
            <div
              key={img.src}
              className={`group relative overflow-hidden rounded-xl transition-all duration-700 ${index === 0 ? "md:col-span-2 md:row-span-2" : ""} ${isVisible ? "scale-100 opacity-100" : "scale-95 opacity-0"}`}
              style={{ transitionDelay: `${200 + index * 100}ms` }}
            >
              <div className={`relative ${index === 0 ? "aspect-square" : "aspect-[4/3]"}`}>
                <Image src={img.src} alt={img.alt} fill className="object-cover transition-transform duration-700 group-hover:scale-110" sizes={index === 0 ? "(max-width: 1024px) 100vw, 50vw" : "(max-width: 1024px) 50vw, 25vw"} />
                <div className="absolute inset-0 bg-[#050208]/30 transition-opacity duration-300 group-hover:opacity-0" />
                <div className="absolute inset-0 rounded-xl border border-primary/0 transition-all duration-300 group-hover:border-primary/30 group-hover:neon-border" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function Sponsors() {
  const { ref: sectionRef, isVisible } = useInView(0.2)
  return (
    <section id="patrocinio" ref={sectionRef} className="relative py-24 lg:py-32">
      <div className="absolute left-1/2 top-0 h-96 w-96 -translate-x-1/2 rounded-full bg-primary/5 blur-[120px]" />
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className={`relative overflow-hidden rounded-2xl border border-border bg-card p-8 md:p-16 transition-all duration-700 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}>
          <div className="absolute -left-20 -top-20 h-64 w-64 rounded-full bg-primary/10 blur-[80px]" />
          <div className="absolute -bottom-20 -right-20 h-64 w-64 rounded-full bg-accent/10 blur-[80px]" />
          <div className="relative text-center">
            <span className="mb-4 inline-block text-sm font-semibold uppercase tracking-widest text-primary">Patrocinio</span>
            <h2 className="mb-6 text-4xl font-bold text-foreground md:text-5xl text-balance">Patrocinio confirmado</h2>
            <div className="mb-10 flex items-center justify-center">
              <div className="flex items-center justify-center rounded-2xl border border-border bg-secondary/50 px-12 py-8">
                <span className="text-4xl font-black uppercase tracking-wider text-foreground md:text-5xl">BRAHMA</span>
              </div>
            </div>
            <div className="mx-auto mb-10 h-px w-48 bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
            <div className="flex flex-col items-center gap-4">
              <div className="flex items-center gap-2">
                <Handshake className="h-5 w-5 text-muted-foreground" />
                <p className="text-lg text-muted-foreground">Marcas interessadas em parceria, entre em contato</p>
              </div>
              <WhatsAppCTA variant="outline" isSponsor>Quero ser patrocinador</WhatsAppCTA>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function FinalCTA() {
  const { ref: sectionRef, isVisible } = useInView(0.2)
  return (
    <section ref={sectionRef} className="relative overflow-hidden py-24 lg:py-32">
      <div className="absolute left-1/4 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-primary/10 blur-[120px] animate-glow-pulse" />
      <div className="absolute right-1/4 top-1/2 h-72 w-72 -translate-y-1/2 rounded-full bg-accent/10 blur-[100px] animate-glow-pulse" style={{ animationDelay: "1.5s" }} />
      <div className={`relative mx-auto max-w-4xl px-4 text-center transition-all duration-700 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}>
        <h2 className="mb-6 text-4xl font-black uppercase text-foreground md:text-6xl lg:text-7xl text-balance">
          Garanta sua vaga no after mais <span className="neon-text text-primary">disputado</span> de BH
        </h2>
        <p className="mx-auto mb-10 max-w-xl text-lg text-muted-foreground">
          Vagas limitadas. Nao fique de fora da noite que vai marcar a historia da cena noturna de Belo Horizonte.
        </p>
        <WhatsAppCTA variant="large">Garantir minha vaga</WhatsAppCTA>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="border-t border-border bg-card py-12">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="flex flex-col items-center gap-8 md:flex-row md:justify-between">
          <div className="text-center md:text-left">
            <p className="text-xl font-bold tracking-wider text-foreground">VIBE<span className="text-primary"> AFTER</span> BH</p>
            <p className="mt-1 text-sm text-muted-foreground">O after mais insano de Belo Horizonte</p>
          </div>
          <div className="flex items-center gap-6">
            <a href="https://instagram.com/vibeafterbh" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary" aria-label="Instagram do VIBE AFTER BH">
              <Instagram className="h-5 w-5" /><span className="hidden sm:inline">@vibeafterbh</span>
            </a>
            <a href="mailto:contato@vibeafterbh.com" className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary" aria-label="Email de contato">
              <Mail className="h-5 w-5" /><span className="hidden sm:inline">contato@vibeafterbh.com</span>
            </a>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4" /><span>Belo Horizonte - MG</span>
          </div>
        </div>
        <div className="mt-8 border-t border-border pt-8 text-center">
          <p className="text-xs text-muted-foreground">{"VIBE AFTER BH - Todos os direitos reservados."}</p>
        </div>
      </div>
    </footer>
  )
}

function FloatingWhatsApp() {
  return (
    <a
      href={WHATSAPP_LINK}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] shadow-[0_0_20px_rgba(37,211,102,0.5)] transition-all duration-300 hover:scale-110 hover:shadow-[0_0_30px_rgba(37,211,102,0.7)]"
      aria-label="Contato via WhatsApp"
    >
      <WhatsAppIcon className="h-7 w-7 text-[#050208]" />
    </a>
  )
}

// ── Page ─────────────────────────────────────────────────────────────────────

export default function Page() {
  return (
    <main className="relative min-h-screen overflow-x-hidden bg-background">
      <Navbar />
      <Hero />
      <About />
      <Attractions />
      <Venue />
      <Gallery />
      <Sponsors />
      <FinalCTA />
      <Footer />
      <FloatingWhatsApp />
    </main>
  )
}

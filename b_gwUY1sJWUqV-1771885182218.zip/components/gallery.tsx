"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"

const images = [
  { src: "/images/gallery-1.jpg", alt: "Publico na pista de danca" },
  { src: "/images/gallery-2.jpg", alt: "DJ na mesa de som" },
  { src: "/images/gallery-3.jpg", alt: "Bar com drinks neon" },
  { src: "/images/gallery-4.jpg", alt: "Area VIP da festa" },
]

export function Gallery() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true)
      },
      { threshold: 0.1 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section id="galeria" ref={sectionRef} className="relative py-24 lg:py-32">
      <div className="absolute right-0 bottom-0 h-96 w-96 rounded-full bg-neon-pink/5 blur-[120px]" />

      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        {/* Section header */}
        <div className={`mb-16 text-center transition-all duration-700 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}>
          <span className="mb-4 inline-block text-sm font-semibold uppercase tracking-widest text-primary">
            Galeria
          </span>
          <h2 className="mb-4 text-4xl font-bold text-foreground md:text-5xl text-balance">
            Sinta a energia
          </h2>
          <p className="mx-auto max-w-md text-muted-foreground">
            Momentos das nossas edicoes anteriores
          </p>
        </div>

        {/* Gallery grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {images.map((img, index) => (
            <div
              key={img.src}
              className={`group relative overflow-hidden rounded-xl transition-all duration-700 ${
                index === 0 ? "md:col-span-2 md:row-span-2" : ""
              } ${isVisible ? "scale-100 opacity-100" : "scale-95 opacity-0"}`}
              style={{ transitionDelay: `${200 + index * 100}ms` }}
            >
              <div className={`relative ${index === 0 ? "aspect-square" : "aspect-[4/3]"}`}>
                <Image
                  src={img.src}
                  alt={img.alt}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                  sizes={index === 0 ? "(max-width: 1024px) 100vw, 50vw" : "(max-width: 1024px) 50vw, 25vw"}
                />
                <div className="absolute inset-0 bg-[#050208]/30 transition-opacity duration-300 group-hover:opacity-0" />
                <div className="absolute inset-0 rounded-xl border border-primary/0 transition-all duration-300 group-hover:border-primary/30 group-hover:neon-border" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

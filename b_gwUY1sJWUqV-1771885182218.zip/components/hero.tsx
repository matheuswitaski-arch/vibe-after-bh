"use client"

import { useEffect, useRef } from "react"
import Image from "next/image"
import { CalendarDays, Clock, MapPin } from "lucide-react"
import { WhatsAppCTA } from "./whatsapp-button"

export function Hero() {
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      if (heroRef.current) {
        const scrollY = window.scrollY
        heroRef.current.style.transform = `translateY(${scrollY * 0.3}px)`
      }
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <section className="relative flex min-h-screen items-center justify-center overflow-hidden">
      {/* Background image with parallax */}
      <div ref={heroRef} className="absolute inset-0 -z-10">
        <Image
          src="/images/hero-bg.jpg"
          alt="VIBE AFTER BH - festa"
          fill
          priority
          className="object-cover"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-[#050208]/70" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#050208]/30 via-transparent to-[#050208]" />
      </div>

      {/* Neon glow effects */}
      <div className="absolute left-1/4 top-1/4 h-96 w-96 rounded-full bg-primary/20 blur-[120px] animate-glow-pulse" />
      <div className="absolute right-1/4 bottom-1/4 h-72 w-72 rounded-full bg-accent/20 blur-[100px] animate-glow-pulse" style={{ animationDelay: "1.5s" }} />

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-5xl px-4 text-center">
        {/* Date badge */}
        <div className="mb-8 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2">
          <CalendarDays className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium text-primary">15 de Marco de 2026</span>
        </div>

        {/* Event name */}
        <h1 className="mb-2 text-6xl font-black uppercase tracking-tight text-foreground md:text-8xl lg:text-9xl">
          <span className="block">VIBE</span>
          <span className="neon-text block text-primary">AFTER</span>
          <span className="block text-3xl font-bold tracking-[0.3em] text-muted-foreground md:text-4xl">
            BELO HORIZONTE
          </span>
        </h1>

        {/* Tagline */}
        <p className="mx-auto mb-8 max-w-xl text-lg font-medium text-foreground/80 md:text-xl text-balance">
          O after mais insano de BH
        </p>

        {/* Info pills */}
        <div className="mb-10 flex flex-wrap items-center justify-center gap-4">
          <div className="flex items-center gap-2 rounded-full border border-border bg-secondary/50 px-4 py-2">
            <Clock className="h-4 w-4 text-primary" />
            <span className="text-sm text-muted-foreground">23h - 06h</span>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-border bg-secondary/50 px-4 py-2">
            <MapPin className="h-4 w-4 text-accent" />
            <span className="text-sm text-muted-foreground">Casa exclusiva - BH</span>
          </div>
        </div>

        {/* CTA */}
        <WhatsAppCTA variant="large">
          Quero participar
        </WhatsAppCTA>

        {/* Scroll indicator */}
        <div className="mt-16 flex flex-col items-center gap-2">
          <span className="text-xs uppercase tracking-widest text-muted-foreground">Role para baixo</span>
          <div className="h-10 w-[1px] bg-gradient-to-b from-primary/60 to-transparent animate-glow-pulse" />
        </div>
      </div>
    </section>
  )
}

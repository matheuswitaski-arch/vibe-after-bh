"use client"

import { useEffect, useRef, useState } from "react"
import { WhatsAppCTA } from "./whatsapp-button"

export function FinalCTA() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true)
      },
      { threshold: 0.2 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="relative overflow-hidden py-24 lg:py-32">
      {/* Background glows */}
      <div className="absolute left-1/4 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-primary/10 blur-[120px] animate-glow-pulse" />
      <div className="absolute right-1/4 top-1/2 h-72 w-72 -translate-y-1/2 rounded-full bg-accent/10 blur-[100px] animate-glow-pulse" style={{ animationDelay: "1.5s" }} />

      <div
        className={`relative mx-auto max-w-4xl px-4 text-center transition-all duration-700 ${
          isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"
        }`}
      >
        <h2 className="mb-6 text-4xl font-black uppercase text-foreground md:text-6xl lg:text-7xl text-balance">
          Garanta sua vaga no after mais
          <span className="neon-text text-primary"> disputado </span>
          de BH
        </h2>
        <p className="mx-auto mb-10 max-w-xl text-lg text-muted-foreground">
          Vagas limitadas. Nao fique de fora da noite que vai marcar a historia da cena noturna de Belo Horizonte.
        </p>
        <WhatsAppCTA variant="large">
          Garantir minha vaga
        </WhatsAppCTA>
      </div>
    </section>
  )
}
